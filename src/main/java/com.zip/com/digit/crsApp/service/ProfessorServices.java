package com.digit.crsApp.service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import com.crsApp.CRSApp;
import com.digit.crsApp.beans.Professor;
import com.digit.crsApp.beans.Student;

public class ProfessorServices {
	static int sid;
	static int marks;
	private static PreparedStatement pstmt;
    static String check;
	private static ResultSet resultset;
	private static Statement stmt;
	public static void grade_marks(){
		
		try {

			// Professor p = new Professor(1, "mudu",5);int pid, String pname, int exp
			Scanner sc = new Scanner(System.in);
			System.out.println("add student marks");
			System.out.println("Enter student id");
			sid = sc.nextInt();
			System.out.println("Enter student marks");
			marks = sc.nextInt();
				ProfessorServices ps = new ProfessorServices(sid, marks);
				String sql = "insert into marks values(?,?)";
				pstmt = CRSApp.con.prepareStatement(sql);
				pstmt.setInt(1, ps.getSid());
				pstmt.setInt(2, ps.getMarks());
				

				int x = pstmt.executeUpdate();
				if (x > 0) {
					String sql1="select Sname from student where sid=?";
					pstmt = CRSApp.con.prepareStatement(sql1);
					pstmt.setInt(1, ps.getSid());
					resultset=pstmt.executeQuery();
					while(resultset.next()==true) {
						System.out.println( resultset.getString("sname")+" student marks Added------------ :");
					}

				}
				
			
			CRSApp.sleep(3000);
			System.out.println("\n\t\tstudent marks Added Successfully...");
			System.out.println("\n****************************************\n");
			System.out.println("Do you want to grade more student : y/n");
			check=sc.next();
			if(check.equals("y")) {
				grade_marks();
			}
			else if(check.equals("n")){
				System.out.println("Do you want to go the management : y/n");
				check=sc.next();
				if(check.equals("y")) {
					CRSApp.manage();
				}
				else if(check.equals("n")){
					System.out.println("\ngo to menu");
					AdminServices.menu();
				}
			}
			

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public ProfessorServices(int sid, int marks) {
		super();
		this.sid = sid;
		this.marks = marks;
	}
	/**
	 * @return the sid
	 */
	public int getSid() {
		return sid;
	}
	/**
	 * @param sid the sid to set
	 */
	public void setSid(int sid) {
		this.sid = sid;
	}
	/**
	 * @return the marks
	 */
	public int getMarks() {
		return marks;
	}
	/**
	 * @param marks the marks to set
	 */
	public void setMarks(int marks) {
		this.marks = marks;
	}
	
	
}
