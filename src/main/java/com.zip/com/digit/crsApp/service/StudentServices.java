package com.digit.crsApp.service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import com.crsApp.CRSApp;

public class StudentServices {
	 static int sid;
	private static PreparedStatement pstmt;
    static String check;
	private static ResultSet resultset;
	private static Statement stmt;
	public StudentServices(int sid) {
		this.sid = sid;
		
	}
	/**
	 * @return the sid
	 */
	public static int getSid() {
		return sid;
	}
	/**
	 * @param sid the sid to set
	 */
	public void setSid(int sid) {
		this.sid = sid;
	}
	
	
	public static void show_marks() {
		Scanner sc=new Scanner(System.in);
		try {
		System.out.println("Enter student id");
		sid = sc.nextInt();
		StudentServices ps = new StudentServices(sid);
		String sql1="select Sname from student where sid=?";
		pstmt = CRSApp.con.prepareStatement(sql1);
		pstmt.setInt(1, ps.getSid());
		resultset=pstmt.executeQuery();
		while(resultset.next()==true) {
			System.out.println("Name of the student....");
			System.out.println( resultset.getString("sname"));
		}
		String sql2="select marks from marks where sid=?";
		pstmt = CRSApp.con.prepareStatement(sql2);
		pstmt.setInt(1, ps.getSid());
		resultset=pstmt.executeQuery();
		while(resultset.next()==true) {
			System.out.println("Marks of the student....");
			System.out.println( resultset.getInt("marks"));
		}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
